I hereby declare that this submission is my own original work and to the best of my
knowledge it contains no materials previously published or written by another person. I
am aware that submitting solutions that are not my own work will result in an NC of the
course.
I am aware that I am not allowed to share solutions with other students.
I am aware that if I submit only parts of this lab that points will be subtracted.
I am aware that if my lab submission does not contain this readme.txt file that I do not get
points for this lab.

Shree Krishna Poudel