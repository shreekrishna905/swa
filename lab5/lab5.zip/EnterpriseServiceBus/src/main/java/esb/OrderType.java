package esb;

public enum OrderType {
    INTERNATIONAL, DOMESTIC
}
